(function(){
  try{
    var old=document.getElementById('__lb_reader');
    if(old){old.remove();return 'closed';}
    var src=document.querySelector('article')||document.querySelector('main')||document.querySelector('[role=main]')||document.body;
    var nodes=src.querySelectorAll('h1,h2,h3,h4,p,li,blockquote,pre,img,figcaption');
    var pt=(window.__lbPadTop||90),pb=(window.__lbPadBottom||90);
    var box=document.createElement('div');
    box.id='__lb_reader';
    box.style.cssText='position:fixed;left:0;top:0;right:0;bottom:0;z-index:2147483647;overflow:auto;background:#12151f;color:#e8eaf2;font:18px/1.7 Georgia,serif;padding:'+pt+'px 22px '+pb+'px;box-sizing:border-box;-webkit-text-size-adjust:100%';
    var h=document.createElement('h1');
    h.textContent=document.title||'';
    h.style.cssText='font-size:26px;line-height:1.25;margin:0 0 18px;color:#fff';
    box.appendChild(h);
    var seen=0;
    for(var i=0;i<nodes.length;i++){
      var n=nodes[i],tag=n.tagName.toLowerCase();
      if(tag==='img'){
        if((n.naturalWidth||0)<150)continue;
        var im=document.createElement('img');
        im.src=n.currentSrc||n.src;
        im.style.cssText='max-width:100%;height:auto;border-radius:14px;margin:12px 0;display:block';
        box.appendChild(im);
        continue;
      }
      var txt=(n.innerText||'').trim();
      if(txt.length<(tag.charAt(0)==='h'?2:25))continue;
      var el=document.createElement((tag==='li'||tag==='figcaption')?'p':tag);
      el.textContent=(tag==='li'?'\u2022 ':'')+txt;
      el.style.cssText='margin:0 0 14px'+(tag==='figcaption'?';opacity:.65;font-size:15px':'');
      box.appendChild(el);
      seen++;
    }
    if(seen<2)return 'none';
    var x=document.createElement('div');
    x.textContent='\u2715';
    x.style.cssText='position:fixed;right:18px;top:'+(pt-4)+'px;width:38px;height:38px;border-radius:19px;background:rgba(255,255,255,.14);color:#fff;font:18px/38px sans-serif;text-align:center;z-index:2147483647';
    x.onclick=function(){box.remove();x.remove();};
    document.body.appendChild(box);
    document.body.appendChild(x);
    return 'ok';
  }catch(e){return 'none';}
})();
