package com.liquid.browser;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/** Kaca cair: isi tembus pandang, kilau di atas, dan tepi berwarna cyan ke pink. */
public class GlassDrawable extends Drawable {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint hi = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final float radius, stroke;
    private final int fillTop, fillBottom, rimA, rimB;

    public GlassDrawable(float radius, float stroke, int fillTop, int fillBottom, int rimA, int rimB) {
        this.radius = radius;
        this.stroke = stroke;
        this.fillTop = fillTop;
        this.fillBottom = fillBottom;
        this.rimA = rimA;
        this.rimB = rimB;
        rim.setStyle(Paint.Style.STROKE);
        rim.setStrokeWidth(stroke);
    }

    @Override
    protected void onBoundsChange(Rect b) {
        fill.setShader(new LinearGradient(0, b.top, 0, b.bottom, fillTop, fillBottom, Shader.TileMode.CLAMP));
        hi.setShader(new LinearGradient(0, b.top, 0, b.top + b.height() * 0.55f,
                0x40FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        rim.setShader(new LinearGradient(b.left, b.top, b.right, b.bottom,
                new int[]{rimA, 0x26FFFFFF, 0x26FFFFFF, rimB}, new float[]{0f, 0.35f, 0.65f, 1f},
                Shader.TileMode.CLAMP));
    }

    @Override
    public void draw(Canvas c) {
        r.set(getBounds());
        float h = stroke / 2f;
        r.inset(h, h);
        float rad = Math.min(radius, Math.min(r.width(), r.height()) / 2f);
        if (((fillTop >>> 24) | (fillBottom >>> 24)) != 0) c.drawRoundRect(r, rad, rad, fill);
        if (((fillTop >>> 24) | (fillBottom >>> 24)) != 0) c.drawRoundRect(r, rad, rad, hi);
        c.drawRoundRect(r, rad, rad, rim);
    }

    @Override
    public void getOutline(Outline o) {
        Rect b = getBounds();
        o.setRoundRect(b, Math.min(radius, Math.min(b.width(), b.height()) / 2f));
        o.setAlpha(0f);
    }

    @Override public void setAlpha(int a) { fill.setAlpha(a); rim.setAlpha(a); hi.setAlpha(a); invalidateSelf(); }
    @Override public void setColorFilter(ColorFilter cf) { }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
