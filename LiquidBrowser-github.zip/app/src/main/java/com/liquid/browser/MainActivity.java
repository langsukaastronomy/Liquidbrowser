package com.liquid.browser;

import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.PorterDuff;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.pm.ShortcutInfoCompat;
import androidx.core.content.pm.ShortcutManagerCompat;
import androidx.core.graphics.ColorUtils;
import androidx.core.graphics.Insets;
import androidx.core.graphics.drawable.IconCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private static final String HOME = "file:///android_asset/start.html";
    private static final String DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

    private FrameLayout root;
    private WebView web;
    private EditText urlBox;
    private ProgressBar progress;
    private View topBar, bottomBar, scrimTop, scrimBottom;

    private static final int[] ICONS = {R.drawable.ic_back, R.drawable.ic_forward, R.drawable.ic_home, R.drawable.ic_refresh, R.drawable.ic_share};
    private static final String[] LABELS = {"Kembali", "Maju", "Beranda", "Muat", "Bagikan"};
    private final LinearLayout[] items = new LinearLayout[5];
    private final ImageView[] itemIcons = new ImageView[5];
    private final TextView[] itemLabels = new TextView[5];
    private View lens;
    private float rowPad, lastTouchX, lensVel;
    private int lastIdx = -1;
    private ValueAnimator lensAnim;
    private final Runnable lensDecay = () -> lens.animate().scaleX(1f).scaleY(1f).setStartDelay(0)
            .setDuration(200).setInterpolator(new DecelerateInterpolator()).start();
    private final Runnable lensFade = () -> lens.animate().alpha(0f).scaleX(0.85f).scaleY(0.85f)
            .setStartDelay(0).setDuration(280).setInterpolator(new AccelerateInterpolator())
            .setUpdateListener(a -> applyTints()).start();

    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;
    private ValueCallback<Uri[]> filePathCallback;
    private boolean closing = false;
    private long introUntil = 0;

    private int topInset, bottomInset, padTopPx, padBottomPx;
    private boolean barsHidden = false;
    private boolean findMode = false;
    private boolean desktopMode = false;
    private String mobileUa = "";
    private FrameLayout overlay;

    private final ActivityResultLauncher<Intent> fileLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (filePathCallback == null) return;
                Uri[] res = null;
                if (result.getData() != null) {
                    res = WebChromeClient.FileChooserParams.parseResult(result.getResultCode(), result.getData());
                }
                filePathCallback.onReceiveValue(res);
                filePathCallback = null;
            });

    private final ActivityResultLauncher<Intent> photoLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() != RESULT_OK || result.getData() == null) return;
                Uri picked = result.getData().getData();
                if (picked != null) importPhoto(picked);
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_main);

        root = findViewById(R.id.root);
        web = findViewById(R.id.web);
        urlBox = findViewById(R.id.urlBox);
        progress = findViewById(R.id.progress);
        topBar = findViewById(R.id.topBar);
        bottomBar = findViewById(R.id.bottomBar);
        scrimTop = findViewById(R.id.scrimTop);
        scrimBottom = findViewById(R.id.scrimBottom);
        topBar.setBackground(new GlassDrawable(dpf(40), dpf(1.2f), 0xCC2A3358, 0xCC121628, 0xB07DEBFF, 0xB0FF9AD5));

        WindowInsetsControllerCompat wic = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        wic.setAppearanceLightStatusBars(false);
        wic.setAppearanceLightNavigationBars(false);

        setupInsets();
        setupWeb();
        setupBars();

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (overlay != null) dismissOverlay(true);
                else if (findMode) {
                    exitFindMode();
                    urlBox.clearFocus();
                } else if (customView != null) hideCustom();
                else if (web.canGoBack()) web.goBack();
                else playOutro();
            }
        });

        applyBackground(false);

        Uri data = getIntent() != null ? getIntent().getData() : null;
        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl(data != null ? data.toString() : homeUrl());

        playIntro();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private float dpf(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    // ------------------------------------------------------------------ insets & web

    private void setupInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            int ime = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom;
            boolean imeOn = insets.isVisible(WindowInsetsCompat.Type.ime());
            int gap = dp(10), topH = dp(52), botH = dp(64);
            topInset = bars.top;
            bottomInset = bars.bottom;

            FrameLayout.LayoutParams t = (FrameLayout.LayoutParams) topBar.getLayoutParams();
            t.topMargin = bars.top + gap;
            topBar.setLayoutParams(t);

            FrameLayout.LayoutParams p = (FrameLayout.LayoutParams) progress.getLayoutParams();
            p.topMargin = bars.top + gap + topH + dp(3);
            progress.setLayoutParams(p);

            FrameLayout.LayoutParams b = (FrameLayout.LayoutParams) bottomBar.getLayoutParams();
            b.bottomMargin = bars.bottom + gap;
            bottomBar.setLayoutParams(b);
            bottomBar.setVisibility(imeOn ? View.GONE : View.VISIBLE);

            FrameLayout.LayoutParams w = (FrameLayout.LayoutParams) web.getLayoutParams();
            w.topMargin = 0;
            w.bottomMargin = imeOn ? ime : 0;
            web.setLayoutParams(w);

            FrameLayout.LayoutParams st = (FrameLayout.LayoutParams) scrimTop.getLayoutParams();
            st.height = bars.top + dp(18);
            scrimTop.setLayoutParams(st);
            FrameLayout.LayoutParams sb = (FrameLayout.LayoutParams) scrimBottom.getLayoutParams();
            sb.height = bars.bottom + dp(18);
            scrimBottom.setLayoutParams(sb);

            padTopPx = bars.top + gap + topH + dp(8);
            padBottomPx = bars.bottom + gap + botH + dp(10);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    /** Memberi ruang di atas/bawah halaman supaya isi tidak tertutup bar kaca. */
    private void injectInsets() {
        float d = getResources().getDisplayMetrics().density;
        float screenDp = getResources().getDisplayMetrics().widthPixels / d;
        float topDp = padTopPx / d;
        float botDp = padBottomPx / d;
        String js = "(function(){try{var k=window.innerWidth/" + screenDp + ";var e=document.documentElement;"
                + "e.style.setProperty('padding-top',(" + topDp + "*k)+'px','important');"
                + "e.style.setProperty('padding-bottom',(" + botDp + "*k)+'px','important');}catch(x){}})();";
        web.evaluateJavascript(js, null);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWeb() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setAllowFileAccess(false);
        mobileUa = s.getUserAgentString().replace("; wv", "").replaceAll("Version/\\d+\\.\\d+ ", "");
        s.setUserAgentString(mobileUa);

        web.setBackgroundColor(Color.TRANSPARENT);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.setOnScrollChangeListener((v, sx, sy, osx, osy) -> onWebScroll(sy, sy - osy));

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("liquid.local".equals(u.getHost()) && "/bg.jpg".equals(u.getPath())) {
                    File f = new File(getFilesDir(), "bg.jpg");
                    if (f.exists()) {
                        try {
                            WebResourceResponse res = new WebResourceResponse("image/jpeg", null, new FileInputStream(f));
                            Map<String, String> headers = new HashMap<>();
                            headers.put("Cache-Control", "no-store");
                            res.setResponseHeaders(headers);
                            return res;
                        } catch (Exception ignored) { }
                    }
                }
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String sc = u.getScheme();
                if (sc == null) return false;
                if (sc.equals("http") || sc.equals("https") || sc.equals("file") || sc.equals("about")
                        || sc.equals("data") || sc.equals("blob") || sc.equals("javascript")) return false;
                try {
                    Intent i = "intent".equals(sc)
                            ? Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME)
                            : new Intent(Intent.ACTION_VIEW, u);
                    startActivity(i);
                } catch (Exception ignored) { }
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap favicon) {
                showUrl(url);
                progress.setVisibility(View.VISIBLE);
                setBars(true);
                dimWeb();
            }

            @Override
            public void onPageCommitVisible(WebView v, String url) {
                applyDesktopViewport();
                injectInsets();
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                progress.setVisibility(View.INVISIBLE);
                applyDesktopViewport();
                injectInsets();
                updateNav();
                showWeb();
                if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                    String t = v.getTitle();
                    Store.addFront(MainActivity.this, "hist", TextUtils.isEmpty(t) ? url : t, url, 150);
                }
            }

            @Override
            public void doUpdateVisitedHistory(WebView v, String url, boolean isReload) {
                updateNav();
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                progress.setProgress(p);
                progress.setVisibility(p >= 100 ? View.INVISIBLE : View.VISIBLE);
                if (p >= 70 && web.getAlpha() < 1f) showWeb();
            }

            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                try {
                    fileLauncher.launch(params.createIntent());
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback cb) {
                if (customView != null) { cb.onCustomViewHidden(); return; }
                customView = view;
                customCallback = cb;
                root.addView(view, new FrameLayout.LayoutParams(-1, -1));
                topBar.setVisibility(View.GONE);
                bottomBar.setVisibility(View.GONE);
                progress.setVisibility(View.GONE);
                web.setVisibility(View.INVISIBLE);
                WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
                c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                c.hide(WindowInsetsCompat.Type.systemBars());
            }

            @Override
            public void onHideCustomView() {
                hideCustom();
            }
        });

        web.setDownloadListener((url, ua, cd, mime, len) -> {
            try {
                DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                r.setMimeType(mime);
                r.addRequestHeader("User-Agent", ua);
                String cookies = CookieManager.getInstance().getCookie(url);
                if (cookies != null) r.addRequestHeader("Cookie", cookies);
                String name = URLUtil.guessFileName(url, cd, mime);
                r.setTitle(name);
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
                toast("Mengunduh " + name);
            } catch (Exception e) {
                toast("Gagal mengunduh file");
            }
        });
    }

    private void hideCustom() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        if (customCallback != null) customCallback.onCustomViewHidden();
        customCallback = null;
        web.setVisibility(View.VISIBLE);
        topBar.setVisibility(View.VISIBLE);
        bottomBar.setVisibility(View.VISIBLE);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView())
                .show(WindowInsetsCompat.Type.systemBars());
        ViewCompat.requestApplyInsets(root);
    }

    // ------------------------------------------------------------------ bar visibility

    private void onWebScroll(int sy, int dy) {
        if (overlay != null || findMode || customView != null || closing) return;
        if (sy < dp(30)) {
            setBars(true);
            return;
        }
        if (dy > dp(6)) setBars(false);
        else if (dy < -dp(6)) setBars(true);
    }

    private void setBars(boolean show) {
        if (SystemClock.uptimeMillis() < introUntil) return;
        boolean wantHidden = !show;
        if (barsHidden == wantHidden) return;
        barsHidden = wantHidden;
        float topTo = show ? 0f : -(topBar.getHeight() + topInset + dp(24));
        float botTo = show ? 0f : (bottomBar.getHeight() + bottomInset + dp(24));
        float a = show ? 1f : 0f;
        topBar.animate().translationY(topTo).alpha(a).setStartDelay(0).setDuration(260)
                .setInterpolator(new DecelerateInterpolator()).start();
        progress.animate().translationY(topTo).alpha(a).setStartDelay(0).setDuration(260)
                .setInterpolator(new DecelerateInterpolator()).start();
        bottomBar.animate().translationY(botTo).alpha(a).setStartDelay(0).setDuration(260)
                .setInterpolator(new DecelerateInterpolator()).start();
    }

    // ------------------------------------------------------------------ top bar & url

    private void setupBars() {
        urlBox.setOnEditorActionListener((v, id, ev) -> {
            if (id == EditorInfo.IME_ACTION_GO
                    || (ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                if (findMode) {
                    web.findNext(true);
                    return true;
                }
                load(urlBox.getText().toString());
                urlBox.clearFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.hideSoftInputFromWindow(urlBox.getWindowToken(), 0);
                return true;
            }
            return false;
        });
        urlBox.setOnFocusChangeListener((v, has) -> {
            if (!has) {
                if (findMode) exitFindMode();
                else showUrl(web.getUrl());
            }
        });
        urlBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override
            public void afterTextChanged(Editable e) {
                if (!findMode) return;
                String q = e.toString();
                if (q.isEmpty()) web.clearMatches();
                else web.findAllAsync(q);
            }
        });

        View menu = findViewById(R.id.btnMenu);
        menu.setOnClickListener(v -> showMenu());
        press(menu);

        setupBottomBar();
        updateNav();
    }

    @SuppressLint("ClickableViewAccessibility")
    private void press(View v) {
        v.setOnTouchListener((view, e) -> {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    view.animate().scaleX(0.88f).scaleY(0.88f).setDuration(110).start();
                    break;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    view.animate().scaleX(1f).scaleY(1f).setDuration(260)
                            .setInterpolator(new OvershootInterpolator(3f)).start();
                    break;
                default:
                    break;
            }
            return false;
        });
    }

    private void updateNav() {
        if (items[0] == null) return;
        items[0].setAlpha(web.canGoBack() ? 1f : 0.4f);
        items[1].setAlpha(web.canGoForward() ? 1f : 0.4f);
    }

    private void showUrl(String url) {
        if (urlBox.hasFocus() || findMode) return;
        String neu = (url == null || url.startsWith("file:///android_asset")) ? "" : url;
        if (neu.equals(urlBox.getText().toString())) return;
        urlBox.setText(neu);
        urlBox.setAlpha(0f);
        urlBox.setTranslationY(dp(6));
        urlBox.animate().alpha(1f).translationY(0f).setStartDelay(0).setDuration(260)
                .setInterpolator(new DecelerateInterpolator()).start();
    }

    private void load(String input) {
        String t = input.trim();
        if (t.isEmpty()) return;
        String target;
        if (t.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) {
            target = t;
        } else if (!t.contains(" ") && (t.contains(".") || t.startsWith("localhost"))) {
            target = "https://" + t;
        } else {
            try {
                target = "https://www.bing.com/search?q=" + URLEncoder.encode(t, "UTF-8");
            } catch (Exception e) {
                target = "https://www.bing.com";
            }
        }
        web.loadUrl(target);
    }

    // ------------------------------------------------------------------ page transitions

    private void dimWeb() {
        if (closing || SystemClock.uptimeMillis() < introUntil) return;
        web.animate().cancel();
        web.animate().alpha(0.55f).scaleX(0.99f).scaleY(0.99f).setStartDelay(0).setDuration(160)
                .setInterpolator(new DecelerateInterpolator()).start();
    }

    private void showWeb() {
        if (closing || SystemClock.uptimeMillis() < introUntil) return;
        web.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(380)
                .setInterpolator(new OvershootInterpolator(1.2f)).start();
    }

    private void playIntro() {
        introUntil = SystemClock.uptimeMillis() + 900;
        topBar.setAlpha(0f);
        topBar.setTranslationY(-dp(70));
        bottomBar.setAlpha(0f);
        bottomBar.setTranslationY(dp(90));
        web.setAlpha(0f);
        web.setScaleX(0.94f);
        web.setScaleY(0.94f);
        web.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(80).setDuration(520)
                .setInterpolator(new DecelerateInterpolator(2f)).start();
        topBar.animate().alpha(1f).translationY(0f).setStartDelay(180).setDuration(560)
                .setInterpolator(new OvershootInterpolator(1.1f)).start();
        bottomBar.animate().alpha(1f).translationY(0f).setStartDelay(260).setDuration(560)
                .setInterpolator(new OvershootInterpolator(1.1f)).start();
    }

    private void playOutro() {
        if (closing) return;
        closing = true;
        topBar.animate().alpha(0f).translationY(-dp(70)).setStartDelay(0).setDuration(220)
                .setInterpolator(new AccelerateInterpolator()).start();
        bottomBar.animate().alpha(0f).translationY(dp(90)).setStartDelay(0).setDuration(220)
                .setInterpolator(new AccelerateInterpolator()).start();
        web.animate().alpha(0f).scaleX(0.94f).scaleY(0.94f).setStartDelay(0).setDuration(240)
                .setInterpolator(new AccelerateInterpolator()).withEndAction(this::finish).start();
    }

    // ------------------------------------------------------------------ bottom bar (lensa kaca)

    @SuppressLint("ClickableViewAccessibility")
    private void setupBottomBar() {
        FrameLayout bar = (FrameLayout) bottomBar;
        rowPad = dpf(6);
        bar.setClipChildren(false);
        bar.setClipToPadding(false);
        bar.setBackground(new GlassDrawable(dpf(40), dpf(1.2f), 0xCC2A3358, 0xCC121628, 0xB07DEBFF, 0xB0FF9AD5));

        lens = new View(this);
        lens.setBackground(new GlassDrawable(dpf(34), dpf(1.6f), 0x40FFFFFF, 0x14FFFFFF, 0xF08CE8FF, 0xF0FF9AD5));
        lens.setVisibility(View.INVISIBLE);
        bar.addView(lens, new FrameLayout.LayoutParams(dp(72), dp(72)));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(Math.round(rowPad), 0, Math.round(rowPad), 0);
        bar.addView(row, new FrameLayout.LayoutParams(-1, -1));

        for (int i = 0; i < 5; i++) {
            LinearLayout it = new LinearLayout(this);
            it.setOrientation(LinearLayout.VERTICAL);
            it.setGravity(Gravity.CENTER);
            ImageView iv = new ImageView(this);
            iv.setImageResource(ICONS[i]);
            iv.setColorFilter(Color.WHITE);
            it.addView(iv, new LinearLayout.LayoutParams(dp(22), dp(22)));
            TextView tv = new TextView(this);
            tv.setText(LABELS[i]);
            tv.setTextSize(11f);
            tv.setTextColor(Color.WHITE);
            tv.setSingleLine(true);
            tv.setPadding(0, dp(3), 0, 0);
            it.addView(tv, new LinearLayout.LayoutParams(-2, -2));
            row.addView(it, new LinearLayout.LayoutParams(0, -1, 1f));
            items[i] = it;
            itemIcons[i] = iv;
            itemLabels[i] = tv;
        }

        bar.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, orr, ob) -> {
            int w = r - l, h = b - t;
            float iw = (w - 2 * rowPad) / 5f;
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) lens.getLayoutParams();
            int lw = Math.round(iw * 1.1f), lh = h + dp(10);
            if (lp.width != lw || lp.height != lh) {
                lp.width = lw;
                lp.height = lh;
                lp.topMargin = -dp(5);
                lens.setLayoutParams(lp);
            }
        });

        bar.setClickable(true);
        bar.setOnTouchListener((v, e) -> {
            float x = e.getX();
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: lensDown(x); return true;
                case MotionEvent.ACTION_MOVE: lensMove(x); return true;
                case MotionEvent.ACTION_UP: lensUp(x, true); return true;
                case MotionEvent.ACTION_CANCEL: lensUp(x, false); return true;
                default: return true;
            }
        });
    }

    private float itemW() {
        return (bottomBar.getWidth() - 2 * rowPad) / 5f;
    }

    private float centerOf(int i) {
        return rowPad + itemW() * (i + 0.5f);
    }

    private int indexAt(float c) {
        return Math.max(0, Math.min(4, (int) ((c - rowPad) / itemW())));
    }

    private float clampCenter(float x) {
        return Math.max(centerOf(0), Math.min(centerOf(4), x));
    }

    private void placeLens(float center) {
        lens.setTranslationX(center - lens.getWidth() / 2f);
        applyTints();
    }

    private void applyTints() {
        float c = lens.getTranslationX() + lens.getWidth() / 2f;
        float a = lens.getVisibility() == View.VISIBLE ? lens.getAlpha() : 0f;
        float iw = itemW();
        for (int i = 0; i < 5; i++) {
            float t = Math.max(0f, 1f - Math.abs(c - centerOf(i)) / (iw * 0.85f)) * a;
            int col = ColorUtils.blendARGB(Color.WHITE, 0xFFA5B4FC, t);
            itemIcons[i].setColorFilter(col);
            itemLabels[i].setTextColor(col);
            itemIcons[i].setScaleX(1f + 0.2f * t);
            itemIcons[i].setScaleY(1f + 0.2f * t);
        }
    }

    private void lensDown(float x) {
        if (lensAnim != null) lensAnim.cancel();
        lens.removeCallbacks(lensFade);
        lens.removeCallbacks(lensDecay);
        lens.animate().cancel();
        lastTouchX = x;
        lensVel = 0f;
        float c = clampCenter(x);
        lens.setVisibility(View.VISIBLE);
        lens.setAlpha(0f);
        lens.setScaleX(0.6f);
        lens.setScaleY(0.6f);
        placeLens(c);
        lastIdx = indexAt(c);
        lens.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(240)
                .setInterpolator(new OvershootInterpolator(2f))
                .setUpdateListener(a -> applyTints()).start();
        bottomBar.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
    }

    private void lensMove(float x) {
        float c = clampCenter(x);
        float dx = x - lastTouchX;
        lastTouchX = x;
        lensVel = lensVel * 0.6f + dx * 0.4f;
        placeLens(c);
        int idx = indexAt(c);
        if (idx != lastIdx) {
            lastIdx = idx;
            bottomBar.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
        }
        if (lens.getAlpha() > 0.95f) {
            float st = Math.min(Math.abs(lensVel) / 14f, 0.3f);
            lens.setScaleX(1f + st);
            lens.setScaleY(1f - st * 0.28f);
        }
        lens.removeCallbacks(lensDecay);
        lens.postDelayed(lensDecay, 50);
    }

    private void lensUp(float x, boolean trigger) {
        lens.removeCallbacks(lensDecay);
        int idx = indexAt(clampCenter(x));
        if (trigger) perform(idx);
        final float from = lens.getTranslationX() + lens.getWidth() / 2f;
        final float to = centerOf(idx);
        if (lensAnim != null) lensAnim.cancel();
        lensAnim = ValueAnimator.ofFloat(0f, 1f);
        lensAnim.setDuration(340);
        lensAnim.setInterpolator(new OvershootInterpolator(1.5f));
        lensAnim.addUpdateListener(a -> placeLens(from + (to - from) * (float) a.getAnimatedValue()));
        lensAnim.start();
        lens.animate().scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(300)
                .setInterpolator(new DecelerateInterpolator())
                .setUpdateListener(a -> applyTints()).start();
        lens.removeCallbacks(lensFade);
        lens.postDelayed(lensFade, 460);
    }

    private void perform(int idx) {
        switch (idx) {
            case 0: if (web.canGoBack()) web.goBack(); break;
            case 1: if (web.canGoForward()) web.goForward(); break;
            case 2: web.loadUrl(homeUrl()); break;
            case 3: web.reload(); break;
            default: shareCurrent();
        }
    }

    private void shareCurrent() {
        String u = web.getUrl();
        if (u == null || u.startsWith("file:///android_asset")) {
            toast("Buka sebuah halaman dulu");
            return;
        }
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_TEXT, u);
        startActivity(Intent.createChooser(i, "Bagikan tautan"));
    }

    // ------------------------------------------------------------------ menu (seperti Chrome)

    private boolean isRealPage() {
        String u = web.getUrl();
        return u != null && !u.startsWith("file:///android_asset");
    }

    private FrameLayout newOverlay() {
        FrameLayout o = new FrameLayout(this);
        o.setBackgroundColor(0x66000000);
        o.setClickable(true);
        o.setOnClickListener(v -> dismissOverlay(true));
        o.setAlpha(0f);
        o.animate().alpha(1f).setDuration(180).start();
        return o;
    }

    private void dismissOverlay(boolean animate) {
        final FrameLayout o = overlay;
        if (o == null) return;
        overlay = null;
        if (!animate) {
            root.removeView(o);
            return;
        }
        o.animate().alpha(0f).setDuration(160).withEndAction(() -> root.removeView(o)).start();
    }

    private void showMenu() {
        if (overlay != null) return;
        setBars(true);
        overlay = newOverlay();

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(10), dp(12), dp(10), dp(10));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER);
        boolean bm = isRealPage() && Store.has(this, "bm", web.getUrl());
        addCircle(top, R.drawable.ic_back, web.canGoBack(), () -> web.goBack());
        addCircle(top, R.drawable.ic_forward, web.canGoForward(), () -> web.goForward());
        addCircle(top, bm ? R.drawable.ic_star_filled : R.drawable.ic_star, true, this::toggleBookmark);
        addCircle(top, R.drawable.ic_download, true, this::openDownloads);
        addCircle(top, R.drawable.ic_refresh, true, () -> web.reload());
        panel.addView(top, new LinearLayout.LayoutParams(-1, dp(52)));

        addDivider(panel);
        addRow(panel, R.drawable.ic_add, "Tab baru", -1, this::newWindow);
        addRow(panel, R.drawable.ic_history, "Histori", -1, this::showHistory);
        addRow(panel, R.drawable.ic_delete, "Hapus data penjelajahan", -1, this::confirmClear);
        addDivider(panel);
        addRow(panel, R.drawable.ic_download, "Download", -1, this::openDownloads);
        addRow(panel, R.drawable.ic_bookmark, "Bookmark", -1, this::showBookmarks);
        addDivider(panel);
        addRow(panel, R.drawable.ic_image, "Ganti latar belakang", -1, this::showBackgroundSheet);
        addRow(panel, R.drawable.ic_zoom, "Zoom teks", -1, this::showZoom);
        addRow(panel, R.drawable.ic_share, "Bagikan...", -1, this::shareCurrent);
        addRow(panel, R.drawable.ic_search, "Cari di halaman", -1, this::enterFindMode);
        addRow(panel, R.drawable.ic_translate, "Terjemahkan...", -1, this::translatePage);
        addRow(panel, R.drawable.ic_reader, "Tampilkan Mode Baca", -1, this::readerMode);
        addRow(panel, R.drawable.ic_open, "Buat pintasan", -1, this::pinShortcut);
        addRow(panel, R.drawable.ic_desktop, "Situs desktop", desktopMode ? 1 : 0, this::toggleDesktop);

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setBackground(new GlassDrawable(dpf(28), dpf(1.2f), 0xF2283052, 0xF2111426, 0xB07DEBFF, 0xB0FF9AD5));
        sv.setClickable(true);
        sv.addView(panel);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(290), -2, Gravity.TOP | Gravity.END);
        lp.topMargin = topInset + dp(10) + dp(52) + dp(6);
        lp.rightMargin = dp(12);
        lp.bottomMargin = bottomInset + dp(16);
        overlay.addView(sv, lp);
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));

        sv.setPivotX(dp(290));
        sv.setPivotY(0f);
        sv.setScaleX(0.82f);
        sv.setScaleY(0.82f);
        sv.animate().scaleX(1f).scaleY(1f).setDuration(260)
                .setInterpolator(new OvershootInterpolator(1.4f)).start();
    }

    private void addCircle(LinearLayout parent, int icon, boolean enabled, Runnable action) {
        ImageView iv = new ImageView(this);
        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.OVAL);
        bg.setColor(0x33FFFFFF);
        iv.setBackground(bg);
        iv.setImageResource(icon);
        iv.setColorFilter(Color.WHITE);
        iv.setPadding(dp(12), dp(12), dp(12), dp(12));
        iv.setAlpha(enabled ? 1f : 0.35f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(48), dp(48));
        lp.setMargins(dp(4), 0, dp(4), 0);
        parent.addView(iv, lp);
        if (enabled) {
            iv.setOnClickListener(v -> {
                dismissOverlay(false);
                action.run();
            });
            press(iv);
        }
    }

    private void addDivider(LinearLayout parent) {
        View d = new View(this);
        d.setBackgroundColor(0x24FFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(1));
        lp.setMargins(dp(6), dp(6), dp(6), dp(6));
        parent.addView(d, lp);
    }

    /** checkState: -1 tanpa kotak centang, 0 mati, 1 hidup. */
    private void addRow(LinearLayout parent, int icon, String label, int checkState, Runnable action) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(10), 0, dp(10), 0);

        ImageView iv = new ImageView(this);
        iv.setImageResource(icon);
        iv.setColorFilter(Color.WHITE);
        r.addView(iv, new LinearLayout.LayoutParams(dp(22), dp(22)));

        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(15f);
        tv.setSingleLine(true);
        tv.setPadding(dp(16), 0, 0, 0);
        r.addView(tv, new LinearLayout.LayoutParams(0, -2, 1f));

        if (checkState >= 0) {
            ImageView box = new ImageView(this);
            GradientDrawable g = new GradientDrawable();
            g.setCornerRadius(dpf(6));
            if (checkState == 1) g.setColor(0xFF7DD3FC);
            else g.setStroke(dp(2), 0xCCFFFFFF);
            box.setBackground(g);
            box.setPadding(dp(3), dp(3), dp(3), dp(3));
            if (checkState == 1) {
                box.setImageResource(R.drawable.ic_check);
                box.setColorFilter(0xFF06222B);
            }
            r.addView(box, new LinearLayout.LayoutParams(dp(22), dp(22)));
        }

        r.setOnClickListener(v -> {
            dismissOverlay(false);
            action.run();
        });
        press(r);
        parent.addView(r, new LinearLayout.LayoutParams(-1, dp(48)));
    }

    private interface Pick {
        void on(int index);
    }

    /** Lembar kaca dari bawah: daftar histori/bookmark/zoom dan sebagainya. */
    private void showSheet(String title, String[] primary, String[] secondary, Pick pick, Pick longPick) {
        dismissOverlay(false);
        overlay = newOverlay();

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(14), dp(12), dp(12));

        TextView head = new TextView(this);
        head.setText(title);
        head.setTextColor(Color.WHITE);
        head.setTextSize(17f);
        head.setPadding(dp(8), 0, dp(8), dp(8));
        panel.addView(head, new LinearLayout.LayoutParams(-1, -2));

        if (primary.length == 0) {
            TextView empty = new TextView(this);
            empty.setText("Belum ada data");
            empty.setTextColor(0x99FFFFFF);
            empty.setTextSize(14f);
            empty.setPadding(dp(8), dp(12), dp(8), dp(12));
            panel.addView(empty, new LinearLayout.LayoutParams(-1, -2));
        }

        for (int i = 0; i < primary.length; i++) {
            final int index = i;
            LinearLayout r = new LinearLayout(this);
            r.setOrientation(LinearLayout.VERTICAL);
            r.setPadding(dp(8), dp(9), dp(8), dp(9));
            TextView a = new TextView(this);
            a.setText(primary[i]);
            a.setTextColor(Color.WHITE);
            a.setTextSize(15f);
            a.setSingleLine(true);
            a.setEllipsize(TextUtils.TruncateAt.END);
            r.addView(a, new LinearLayout.LayoutParams(-1, -2));
            if (secondary != null && secondary[i] != null && !secondary[i].isEmpty()) {
                TextView b = new TextView(this);
                b.setText(secondary[i]);
                b.setTextColor(0x99FFFFFF);
                b.setTextSize(12f);
                b.setSingleLine(true);
                b.setEllipsize(TextUtils.TruncateAt.END);
                r.addView(b, new LinearLayout.LayoutParams(-1, -2));
            }
            r.setOnClickListener(v -> {
                dismissOverlay(false);
                pick.on(index);
            });
            if (longPick != null) {
                r.setOnLongClickListener(v -> {
                    longPick.on(index);
                    return true;
                });
            }
            press(r);
            panel.addView(r, new LinearLayout.LayoutParams(-1, -2));
        }

        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        sv.setBackground(new GlassDrawable(dpf(30), dpf(1.2f), 0xF2283052, 0xF2111426, 0xB07DEBFF, 0xB0FF9AD5));
        sv.setClickable(true);
        sv.addView(panel);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        lp.leftMargin = dp(12);
        lp.rightMargin = dp(12);
        lp.bottomMargin = bottomInset + dp(12);
        lp.topMargin = topInset + dp(80);
        overlay.addView(sv, lp);
        root.addView(overlay, new FrameLayout.LayoutParams(-1, -1));

        sv.setTranslationY(dp(60));
        sv.animate().translationY(0f).setDuration(300)
                .setInterpolator(new OvershootInterpolator(1.1f)).start();
    }

    private void showHistory() {
        final List<Store.Entry> list = Store.load(this, "hist");
        String[] t = new String[list.size()];
        String[] u = new String[list.size()];
        for (int i = 0; i < t.length; i++) {
            t[i] = list.get(i).title;
            u[i] = list.get(i).url;
        }
        showSheet("Histori", t, u, i -> web.loadUrl(list.get(i).url), null);
    }

    private void showBookmarks() {
        final List<Store.Entry> list = Store.load(this, "bm");
        String[] t = new String[list.size()];
        String[] u = new String[list.size()];
        for (int i = 0; i < t.length; i++) {
            t[i] = list.get(i).title;
            u[i] = list.get(i).url;
        }
        showSheet("Bookmark (tahan untuk menghapus)", t, u,
                i -> web.loadUrl(list.get(i).url),
                i -> {
                    Store.remove(this, "bm", list.get(i).url);
                    toast("Bookmark dihapus");
                    showBookmarks();
                });
    }

    private void toggleBookmark() {
        String u = web.getUrl();
        if (!isRealPage()) {
            toast("Buka sebuah halaman dulu");
            return;
        }
        if (Store.has(this, "bm", u)) {
            Store.remove(this, "bm", u);
            toast("Bookmark dihapus");
        } else {
            String t = web.getTitle();
            Store.addFront(this, "bm", TextUtils.isEmpty(t) ? u : t, u, 300);
            toast("Bookmark disimpan");
        }
    }

    private void openDownloads() {
        try {
            startActivity(new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS));
        } catch (Exception e) {
            toast("Tidak bisa membuka daftar download");
        }
    }

    private void confirmClear() {
        showSheet("Hapus data penjelajahan?",
                new String[]{"Hapus cache, cookie, dan histori", "Batal"}, null,
                i -> { if (i == 0) clearData(); }, null);
    }

    private void clearData() {
        web.clearCache(true);
        web.clearHistory();
        web.clearFormData();
        CookieManager.getInstance().removeAllCookies(null);
        CookieManager.getInstance().flush();
        WebStorage.getInstance().deleteAllData();
        Store.clear(this, "hist");
        updateNav();
        toast("Data penjelajahan dihapus");
    }

    private void newWindow() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_DOCUMENT | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
        startActivity(i);
    }

    private void showZoom() {
        final int[] levels = {75, 100, 125, 150, 200};
        int cur = web.getSettings().getTextZoom();
        String[] names = new String[levels.length];
        for (int i = 0; i < levels.length; i++) names[i] = (levels[i] == cur ? "\u2713  " : "") + levels[i] + "%";
        showSheet("Zoom teks", names, null, i -> web.getSettings().setTextZoom(levels[i]), null);
    }

    private void enterFindMode() {
        findMode = true;
        urlBox.setText("");
        urlBox.setHint("Cari di halaman");
        urlBox.requestFocus();
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.showSoftInput(urlBox, InputMethodManager.SHOW_IMPLICIT);
    }

    private void exitFindMode() {
        if (!findMode) return;
        findMode = false;
        web.clearMatches();
        urlBox.setHint("Cari atau ketik alamat");
        urlBox.setText("");
        showUrl(web.getUrl());
    }

    private void translatePage() {
        if (!isRealPage()) {
            toast("Buka sebuah halaman dulu");
            return;
        }
        final String[] codes = {"id", "en"};
        showSheet("Terjemahkan halaman (Microsoft)",
                new String[]{"Ke Bahasa Indonesia", "Ke Bahasa Inggris"}, null,
                i -> translateTo(codes[i]), null);
    }

    private void translateTo(String lang) {
        try {
            web.loadUrl("https://www.translatetheweb.com/?from=&to=" + lang + "&a="
                    + URLEncoder.encode(web.getUrl(), "UTF-8"));
        } catch (Exception e) {
            toast("Gagal membuka terjemahan");
        }
    }

    private String readAsset(String name) {
        try (InputStream in = getAssets().open(name)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private void readerMode() {
        if (!isRealPage()) {
            toast("Buka sebuah halaman dulu");
            return;
        }
        float d = getResources().getDisplayMetrics().density;
        String js = "window.__lbPadTop=" + (padTopPx / d) + ";window.__lbPadBottom=" + (padBottomPx / d) + ";"
                + readAsset("reader.js");
        web.evaluateJavascript(js, r -> {
            if (r != null && r.contains("none")) toast("Mode baca tidak tersedia di halaman ini");
        });
    }

    private void pinShortcut() {
        if (!isRealPage()) {
            toast("Buka sebuah halaman dulu");
            return;
        }
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(this)) {
            toast("Peluncur HP tidak mendukung pintasan");
            return;
        }
        String u = web.getUrl();
        Intent i = new Intent(this, MainActivity.class);
        i.setAction(Intent.ACTION_VIEW);
        i.setData(Uri.parse(u));
        String label = web.getTitle();
        if (TextUtils.isEmpty(label)) label = Uri.parse(u).getHost();
        if (TextUtils.isEmpty(label)) label = "Situs";
        ShortcutInfoCompat info = new ShortcutInfoCompat.Builder(this, "pin_" + Integer.toHexString(u.hashCode()))
                .setShortLabel(label)
                .setIcon(IconCompat.createWithResource(this, R.mipmap.ic_launcher))
                .setIntent(i)
                .build();
        ShortcutManagerCompat.requestPinShortcut(this, info, null);
    }

    /** Mode desktop: abaikan lebar layar dari situs agar tampil seperti di komputer. */
    private void applyDesktopViewport() {
        if (!desktopMode) return;
        web.evaluateJavascript("(function(){try{var m=document.querySelector('meta[name=viewport]');"
                + "if(!m){m=document.createElement('meta');m.name='viewport';document.head.appendChild(m);}"
                + "m.setAttribute('content','width=1024, user-scalable=yes, minimum-scale=0.1, maximum-scale=5');}"
                + "catch(e){}})();", null);
    }

    private void toggleDesktop() {
        desktopMode = !desktopMode;
        WebSettings s = web.getSettings();
        s.setUserAgentString(desktopMode ? DESKTOP_UA : mobileUa);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        web.reload();
        toast(desktopMode ? "Situs desktop aktif" : "Situs desktop nonaktif");
    }

    // ------------------------------------------------------------------ latar belakang foto

    private File bgFile() {
        return new File(getFilesDir(), "bg.jpg");
    }

    private String homeUrl() {
        File f = bgFile();
        return f.exists() ? HOME + "?bg=" + f.lastModified() : HOME;
    }

    private void showBackgroundSheet() {
        showSheet("Latar belakang",
                new String[]{"Pilih foto dari galeri", "Kembalikan ke bawaan"}, null,
                i -> {
                    if (i == 0) pickPhoto();
                    else resetBackground();
                }, null);
    }

    private void pickPhoto() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        try {
            photoLauncher.launch(i);
        } catch (ActivityNotFoundException e) {
            toast("Galeri tidak ditemukan");
        }
    }

    private void importPhoto(final Uri uri) {
        toast("Memproses foto...");
        new Thread(() -> {
            boolean ok = false;
            try {
                BitmapFactory.Options bounds = new BitmapFactory.Options();
                bounds.inJustDecodeBounds = true;
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    BitmapFactory.decodeStream(in, null, bounds);
                }
                int sample = 1;
                while (bounds.outWidth / sample > 2400 || bounds.outHeight / sample > 2400) sample *= 2;
                BitmapFactory.Options opts = new BitmapFactory.Options();
                opts.inSampleSize = sample;
                Bitmap bmp;
                try (InputStream in = getContentResolver().openInputStream(uri)) {
                    bmp = BitmapFactory.decodeStream(in, null, opts);
                }
                if (bmp != null) {
                    int rot = 0;
                    try (InputStream in = getContentResolver().openInputStream(uri)) {
                        int ori = new ExifInterface(in).getAttributeInt(
                                ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
                        if (ori == ExifInterface.ORIENTATION_ROTATE_90) rot = 90;
                        else if (ori == ExifInterface.ORIENTATION_ROTATE_180) rot = 180;
                        else if (ori == ExifInterface.ORIENTATION_ROTATE_270) rot = 270;
                    } catch (Exception ignored) { }
                    if (rot != 0) {
                        Matrix m = new Matrix();
                        m.postRotate(rot);
                        bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
                    }
                    int big = Math.max(bmp.getWidth(), bmp.getHeight());
                    if (big > 1600) {
                        float k = 1600f / big;
                        bmp = Bitmap.createScaledBitmap(bmp, Math.round(bmp.getWidth() * k),
                                Math.round(bmp.getHeight() * k), true);
                    }
                    try (FileOutputStream out = new FileOutputStream(bgFile())) {
                        bmp.compress(Bitmap.CompressFormat.JPEG, 86, out);
                    }
                    ok = true;
                }
            } catch (Throwable ignored) { }
            final boolean done = ok;
            runOnUiThread(() -> {
                if (done) {
                    applyBackground(true);
                    toast("Latar belakang diganti");
                } else {
                    toast("Gagal memuat foto");
                }
            });
        }).start();
    }

    private void resetBackground() {
        File f = bgFile();
        if (f.exists()) f.delete();
        applyBackground(true);
        toast("Latar belakang dikembalikan");
    }

    /** Memasang foto di belakang aplikasi; reload = muat ulang beranda agar ikut berganti. */
    private void applyBackground(boolean reload) {
        ImageView iv = findViewById(R.id.bgImage);
        File f = bgFile();
        Bitmap b = f.exists() ? BitmapFactory.decodeFile(f.getAbsolutePath()) : null;
        if (b != null) {
            iv.setImageBitmap(b);
            iv.setColorFilter(0x66050814, PorterDuff.Mode.SRC_ATOP);
            iv.setVisibility(View.VISIBLE);
        } else {
            iv.setImageDrawable(null);
            iv.setVisibility(View.GONE);
        }
        if (reload) {
            String u = web.getUrl();
            if (u == null || u.startsWith("file:///android_asset")) web.loadUrl(homeUrl());
        }
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        Uri d = intent.getData();
        if (d != null) web.loadUrl(d.toString());
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }

    @Override
    protected void onDestroy() {
        web.destroy();
        super.onDestroy();
    }
}
