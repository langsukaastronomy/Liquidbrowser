package com.liquid.browser;

import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Outline;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.view.HapticFeedbackConstants;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.ColorUtils;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import java.net.URLEncoder;

public class MainActivity extends AppCompatActivity {
    private static final String HOME = "file:///android_asset/start.html";

    private FrameLayout root;
    private WebView web;
    private EditText urlBox;
    private ProgressBar progress;
    private View topBar, bottomBar;
    private static final int[] ICONS = {R.drawable.ic_back, R.drawable.ic_forward, R.drawable.ic_home, R.drawable.ic_refresh, R.drawable.ic_share};
    private static final String[] LABELS = {"Kembali", "Maju", "Beranda", "Muat", "Bagikan"};
    private final LinearLayout[] items = new LinearLayout[5];
    private final ImageView[] itemIcons = new ImageView[5];
    private final TextView[] itemLabels = new TextView[5];
    private View lens, webRim;
    private float rowPad, lastTouchX, lensVel;
    private int lastIdx = -1;
    private ValueAnimator lensAnim;
    private final Runnable lensDecay = () -> lens.animate().scaleX(1f).scaleY(1f).setStartDelay(0)
            .setDuration(200).setInterpolator(new DecelerateInterpolator()).start();
    private final Runnable lensFade = () -> lens.animate().alpha(0f).scaleX(0.85f).scaleY(0.85f)
            .setStartDelay(0).setDuration(280).setInterpolator(new AccelerateInterpolator())
            .setUpdateListener(a -> applyTints()).start();
    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;
    private ValueCallback<Uri[]> filePathCallback;
    private boolean closing = false;
    private long introUntil = 0;

    private final ActivityResultLauncher<Intent> fileLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (filePathCallback == null) return;
                Uri[] res = null;
                if (result.getData() != null) {
                    res = WebChromeClient.FileChooserParams.parseResult(result.getResultCode(), result.getData());
                }
                filePathCallback.onReceiveValue(res);
                filePathCallback = null;
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        setContentView(R.layout.activity_main);

        root = findViewById(R.id.root);
        web = findViewById(R.id.web);
        urlBox = findViewById(R.id.urlBox);
        progress = findViewById(R.id.progress);
        topBar = findViewById(R.id.topBar);
        bottomBar = findViewById(R.id.bottomBar);
        webRim = findViewById(R.id.webRim);
        topBar.setBackground(new GlassDrawable(dpf(40), dpf(1.2f), 0xCC2A3358, 0xCC121628, 0xB07DEBFF, 0xB0FF9AD5));
        webRim.setBackground(new GlassDrawable(dpf(26), dpf(1.2f), 0, 0, 0x907DEBFF, 0x80FF9AD5));

        WindowInsetsControllerCompat wic = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        wic.setAppearanceLightStatusBars(false);
        wic.setAppearanceLightNavigationBars(false);

        setupInsets();
        setupWeb();
        setupBars();

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (customView != null) hideCustom();
                else if (web.canGoBack()) web.goBack();
                else playOutro();
            }
        });

        Uri data = getIntent() != null ? getIntent().getData() : null;
        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl(data != null ? data.toString() : HOME);

        playIntro();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void setupInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            int ime = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom;
            boolean imeOn = insets.isVisible(WindowInsetsCompat.Type.ime());
            int gap = dp(10), topH = dp(52), botH = dp(64);

            FrameLayout.LayoutParams t = (FrameLayout.LayoutParams) topBar.getLayoutParams();
            t.topMargin = bars.top + gap;
            topBar.setLayoutParams(t);

            FrameLayout.LayoutParams p = (FrameLayout.LayoutParams) progress.getLayoutParams();
            p.topMargin = bars.top + gap + topH + dp(3);
            progress.setLayoutParams(p);

            FrameLayout.LayoutParams b = (FrameLayout.LayoutParams) bottomBar.getLayoutParams();
            b.bottomMargin = bars.bottom + gap;
            bottomBar.setLayoutParams(b);
            bottomBar.setVisibility(imeOn ? View.GONE : View.VISIBLE);

            FrameLayout.LayoutParams w = (FrameLayout.LayoutParams) web.getLayoutParams();
            w.topMargin = bars.top + gap + topH + dp(10);
            w.bottomMargin = imeOn ? ime + gap : bars.bottom + gap + botH + dp(10);
            web.setLayoutParams(w);
            FrameLayout.LayoutParams rp = (FrameLayout.LayoutParams) webRim.getLayoutParams();
            rp.topMargin = w.topMargin;
            rp.bottomMargin = w.bottomMargin;
            webRim.setLayoutParams(rp);
            return WindowInsetsCompat.CONSUMED;
        });
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWeb() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setAllowFileAccess(false);
        String ua = s.getUserAgentString().replace("; wv", "").replaceAll("Version/\\d+\\.\\d+ ", "");
        s.setUserAgentString(ua);

        web.setBackgroundColor(Color.TRANSPARENT);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View view, Outline outline) {
                outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), dp(26));
            }
        });
        web.setClipToOutline(true);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String sc = u.getScheme();
                if (sc == null) return false;
                if (sc.equals("http") || sc.equals("https") || sc.equals("file") || sc.equals("about")
                        || sc.equals("data") || sc.equals("blob") || sc.equals("javascript")) return false;
                try {
                    Intent i = "intent".equals(sc)
                            ? Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME)
                            : new Intent(Intent.ACTION_VIEW, u);
                    startActivity(i);
                } catch (Exception ignored) { }
                return true;
            }

            @Override
            public void onPageStarted(WebView v, String url, Bitmap favicon) {
                showUrl(url);
                progress.setVisibility(View.VISIBLE);
                dimWeb();
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                progress.setVisibility(View.INVISIBLE);
                updateNav();
                showWeb();
            }

            @Override
            public void doUpdateVisitedHistory(WebView v, String url, boolean isReload) {
                updateNav();
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView v, int p) {
                progress.setProgress(p);
                progress.setVisibility(p >= 100 ? View.INVISIBLE : View.VISIBLE);
                if (p >= 70 && web.getAlpha() < 1f) showWeb();
            }

            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                try {
                    fileLauncher.launch(params.createIntent());
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback cb) {
                if (customView != null) { cb.onCustomViewHidden(); return; }
                customView = view;
                customCallback = cb;
                root.addView(view, new FrameLayout.LayoutParams(-1, -1));
                topBar.setVisibility(View.GONE);
                bottomBar.setVisibility(View.GONE);
                progress.setVisibility(View.GONE);
                web.setVisibility(View.INVISIBLE);
                WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
                c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                c.hide(WindowInsetsCompat.Type.systemBars());
            }

            @Override
            public void onHideCustomView() {
                hideCustom();
            }
        });

        web.setDownloadListener((url, ua, cd, mime, len) -> {
            try {
                DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                r.setMimeType(mime);
                r.addRequestHeader("User-Agent", ua);
                String cookies = CookieManager.getInstance().getCookie(url);
                if (cookies != null) r.addRequestHeader("Cookie", cookies);
                String name = URLUtil.guessFileName(url, cd, mime);
                r.setTitle(name);
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
                Toast.makeText(this, "Mengunduh " + name, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Gagal mengunduh file", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void hideCustom() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        if (customCallback != null) customCallback.onCustomViewHidden();
        customCallback = null;
        web.setVisibility(View.VISIBLE);
        topBar.setVisibility(View.VISIBLE);
        bottomBar.setVisibility(View.VISIBLE);
        WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView())
                .show(WindowInsetsCompat.Type.systemBars());
        ViewCompat.requestApplyInsets(root);
    }

    private void setupBars() {
        urlBox.setOnEditorActionListener((v, id, ev) -> {
            if (id == EditorInfo.IME_ACTION_GO
                    || (ev != null && ev.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {
                load(urlBox.getText().toString());
                urlBox.clearFocus();
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.hideSoftInputFromWindow(urlBox.getWindowToken(), 0);
                return true;
            }
            return false;
        });
        urlBox.setOnFocusChangeListener((v, has) -> { if (!has) showUrl(web.getUrl()); });

        setupBottomBar();
        updateNav();
    }

    private float dpf(float v) {
        return v * getResources().getDisplayMetrics().density;
    }

    @SuppressLint("ClickableViewAccessibility")
    private void setupBottomBar() {
        FrameLayout bar = (FrameLayout) bottomBar;
        rowPad = dpf(6);
        bar.setClipChildren(false);
        bar.setClipToPadding(false);
        bar.setBackground(new GlassDrawable(dpf(40), dpf(1.2f), 0xCC2A3358, 0xCC121628, 0xB07DEBFF, 0xB0FF9AD5));

        lens = new View(this);
        lens.setBackground(new GlassDrawable(dpf(34), dpf(1.6f), 0x40FFFFFF, 0x14FFFFFF, 0xF08CE8FF, 0xF0FF9AD5));
        lens.setVisibility(View.INVISIBLE);
        bar.addView(lens, new FrameLayout.LayoutParams(dp(72), dp(72)));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(Math.round(rowPad), 0, Math.round(rowPad), 0);
        bar.addView(row, new FrameLayout.LayoutParams(-1, -1));

        for (int i = 0; i < 5; i++) {
            LinearLayout it = new LinearLayout(this);
            it.setOrientation(LinearLayout.VERTICAL);
            it.setGravity(android.view.Gravity.CENTER);
            ImageView iv = new ImageView(this);
            iv.setImageResource(ICONS[i]);
            iv.setColorFilter(Color.WHITE);
            it.addView(iv, new LinearLayout.LayoutParams(dp(22), dp(22)));
            TextView tv = new TextView(this);
            tv.setText(LABELS[i]);
            tv.setTextSize(11f);
            tv.setTextColor(Color.WHITE);
            tv.setSingleLine(true);
            tv.setPadding(0, dp(3), 0, 0);
            it.addView(tv, new LinearLayout.LayoutParams(-2, -2));
            row.addView(it, new LinearLayout.LayoutParams(0, -1, 1f));
            items[i] = it;
            itemIcons[i] = iv;
            itemLabels[i] = tv;
        }

        bar.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, orr, ob) -> {
            int w = r - l, h = b - t;
            float iw = (w - 2 * rowPad) / 5f;
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) lens.getLayoutParams();
            int lw = Math.round(iw * 1.1f), lh = h + dp(10);
            if (lp.width != lw || lp.height != lh) {
                lp.width = lw;
                lp.height = lh;
                lp.topMargin = -dp(5);
                lens.setLayoutParams(lp);
            }
        });

        bar.setClickable(true);
        bar.setOnTouchListener((v, e) -> {
            float x = e.getX();
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: lensDown(x); return true;
                case MotionEvent.ACTION_MOVE: lensMove(x); return true;
                case MotionEvent.ACTION_UP: lensUp(x, true); return true;
                case MotionEvent.ACTION_CANCEL: lensUp(x, false); return true;
                default: return true;
            }
        });
    }

    private float itemW() {
        return (bottomBar.getWidth() - 2 * rowPad) / 5f;
    }

    private float centerOf(int i) {
        return rowPad + itemW() * (i + 0.5f);
    }

    private int indexAt(float c) {
        return Math.max(0, Math.min(4, (int) ((c - rowPad) / itemW())));
    }

    private float clampCenter(float x) {
        return Math.max(centerOf(0), Math.min(centerOf(4), x));
    }

    private void placeLens(float center) {
        lens.setTranslationX(center - lens.getWidth() / 2f);
        applyTints();
    }

    private void applyTints() {
        float c = lens.getTranslationX() + lens.getWidth() / 2f;
        float a = lens.getVisibility() == View.VISIBLE ? lens.getAlpha() : 0f;
        float iw = itemW();
        for (int i = 0; i < 5; i++) {
            float t = Math.max(0f, 1f - Math.abs(c - centerOf(i)) / (iw * 0.85f)) * a;
            int col = ColorUtils.blendARGB(Color.WHITE, 0xFFA5B4FC, t);
            itemIcons[i].setColorFilter(col);
            itemLabels[i].setTextColor(col);
            itemIcons[i].setScaleX(1f + 0.2f * t);
            itemIcons[i].setScaleY(1f + 0.2f * t);
        }
    }

    private void lensDown(float x) {
        if (lensAnim != null) lensAnim.cancel();
        lens.removeCallbacks(lensFade);
        lens.removeCallbacks(lensDecay);
        lens.animate().cancel();
        lastTouchX = x;
        lensVel = 0f;
        float c = clampCenter(x);
        lens.setVisibility(View.VISIBLE);
        lens.setAlpha(0f);
        lens.setScaleX(0.6f);
        lens.setScaleY(0.6f);
        placeLens(c);
        lastIdx = indexAt(c);
        lens.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(240)
                .setInterpolator(new OvershootInterpolator(2f))
                .setUpdateListener(a -> applyTints()).start();
        bottomBar.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
    }

    private void lensMove(float x) {
        float c = clampCenter(x);
        float dx = x - lastTouchX;
        lastTouchX = x;
        lensVel = lensVel * 0.6f + dx * 0.4f;
        placeLens(c);
        int idx = indexAt(c);
        if (idx != lastIdx) {
            lastIdx = idx;
            bottomBar.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK);
        }
        if (lens.getAlpha() > 0.95f) {
            float st = Math.min(Math.abs(lensVel) / 14f, 0.3f);
            lens.setScaleX(1f + st);
            lens.setScaleY(1f - st * 0.28f);
        }
        lens.removeCallbacks(lensDecay);
        lens.postDelayed(lensDecay, 50);
    }

    private void lensUp(float x, boolean trigger) {
        lens.removeCallbacks(lensDecay);
        int idx = indexAt(clampCenter(x));
        if (trigger) perform(idx);
        final float from = lens.getTranslationX() + lens.getWidth() / 2f;
        final float to = centerOf(idx);
        if (lensAnim != null) lensAnim.cancel();
        lensAnim = ValueAnimator.ofFloat(0f, 1f);
        lensAnim.setDuration(340);
        lensAnim.setInterpolator(new OvershootInterpolator(1.5f));
        lensAnim.addUpdateListener(a -> placeLens(from + (to - from) * (float) a.getAnimatedValue()));
        lensAnim.start();
        lens.animate().scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(300)
                .setInterpolator(new DecelerateInterpolator())
                .setUpdateListener(a -> applyTints()).start();
        lens.removeCallbacks(lensFade);
        lens.postDelayed(lensFade, 460);
    }

    private void perform(int idx) {
        switch (idx) {
            case 0: if (web.canGoBack()) web.goBack(); break;
            case 1: if (web.canGoForward()) web.goForward(); break;
            case 2: web.loadUrl(HOME); break;
            case 3: web.reload(); break;
            default:
                String u = web.getUrl();
                if (u == null || u.startsWith("file:///android_asset")) {
                    Toast.makeText(this, "Buka sebuah halaman dulu", Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, u);
                startActivity(Intent.createChooser(i, "Bagikan tautan"));
        }
    }

    private void updateNav() {
        if (items[0] == null) return;
        items[0].setAlpha(web.canGoBack() ? 1f : 0.4f);
        items[1].setAlpha(web.canGoForward() ? 1f : 0.4f);
    }

    private void showUrl(String url) {
        if (urlBox.hasFocus()) return;
        String neu = (url == null || url.startsWith("file:///android_asset")) ? "" : url;
        if (neu.equals(urlBox.getText().toString())) return;
        urlBox.setText(neu);
        urlBox.setAlpha(0f);
        urlBox.setTranslationY(dp(6));
        urlBox.animate().alpha(1f).translationY(0f).setStartDelay(0).setDuration(260)
                .setInterpolator(new DecelerateInterpolator()).start();
    }

    private void dimWeb() {
        if (closing || SystemClock.uptimeMillis() < introUntil) return;
        webRim.animate().alpha(0.4f).setDuration(160).start();
        web.animate().cancel();
        web.animate().alpha(0.5f).scaleX(0.985f).scaleY(0.985f).setStartDelay(0).setDuration(160)
                .setInterpolator(new DecelerateInterpolator()).start();
    }

    private void showWeb() {
        if (closing || SystemClock.uptimeMillis() < introUntil) return;
        webRim.animate().alpha(1f).setDuration(380).start();
        web.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(380)
                .setInterpolator(new OvershootInterpolator(1.2f)).start();
    }

    private void playIntro() {
        introUntil = SystemClock.uptimeMillis() + 900;
        topBar.setAlpha(0f);
        topBar.setTranslationY(-dp(70));
        bottomBar.setAlpha(0f);
        bottomBar.setTranslationY(dp(90));
        webRim.setAlpha(0f);
        webRim.animate().alpha(1f).setStartDelay(520).setDuration(300).start();
        web.setAlpha(0f);
        web.setScaleX(0.92f);
        web.setScaleY(0.92f);
        web.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(80).setDuration(520)
                .setInterpolator(new DecelerateInterpolator(2f)).start();
        topBar.animate().alpha(1f).translationY(0f).setStartDelay(180).setDuration(560)
                .setInterpolator(new OvershootInterpolator(1.1f)).start();
        bottomBar.animate().alpha(1f).translationY(0f).setStartDelay(260).setDuration(560)
                .setInterpolator(new OvershootInterpolator(1.1f)).start();
    }

    private void playOutro() {
        if (closing) return;
        closing = true;
        topBar.animate().alpha(0f).translationY(-dp(70)).setStartDelay(0).setDuration(220)
                .setInterpolator(new AccelerateInterpolator()).start();
        bottomBar.animate().alpha(0f).translationY(dp(90)).setStartDelay(0).setDuration(220)
                .setInterpolator(new AccelerateInterpolator()).start();
        webRim.animate().alpha(0f).setStartDelay(0).setDuration(200).start();
        web.animate().alpha(0f).scaleX(0.92f).scaleY(0.92f).setStartDelay(0).setDuration(240)
                .setInterpolator(new AccelerateInterpolator()).withEndAction(this::finish).start();
    }

    private void load(String input) {
        String t = input.trim();
        if (t.isEmpty()) return;
        String target;
        if (t.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*")) {
            target = t;
        } else if (!t.contains(" ") && (t.contains(".") || t.startsWith("localhost"))) {
            target = "https://" + t;
        } else {
            try {
                target = "https://www.bing.com/search?q=" + URLEncoder.encode(t, "UTF-8");
            } catch (Exception e) {
                target = "https://www.bing.com";
            }
        }
        web.loadUrl(target);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        Uri d = intent.getData();
        if (d != null) web.loadUrl(d.toString());
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }

    @Override
    protected void onDestroy() {
        web.destroy();
        super.onDestroy();
    }
}
