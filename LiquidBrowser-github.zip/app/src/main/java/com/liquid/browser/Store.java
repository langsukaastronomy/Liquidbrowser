package com.liquid.browser;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Penyimpanan sederhana untuk bookmark ("bm") dan histori ("hist"). */
final class Store {
    static final class Entry {
        final String title;
        final String url;

        Entry(String title, String url) {
            this.title = title;
            this.url = url;
        }
    }

    private Store() { }

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("lb", Context.MODE_PRIVATE);
    }

    static List<Entry> load(Context c, String key) {
        List<Entry> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp(c).getString(key, "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Entry(o.optString("t"), o.optString("u")));
            }
        } catch (Exception ignored) { }
        return out;
    }

    private static void save(Context c, String key, List<Entry> list) {
        JSONArray a = new JSONArray();
        try {
            for (Entry e : list) {
                JSONObject o = new JSONObject();
                o.put("t", e.title);
                o.put("u", e.url);
                a.put(o);
            }
        } catch (Exception ignored) { }
        sp(c).edit().putString(key, a.toString()).apply();
    }

    static boolean has(Context c, String key, String url) {
        for (Entry e : load(c, key)) if (e.url.equals(url)) return true;
        return false;
    }

    static void addFront(Context c, String key, String title, String url, int cap) {
        List<Entry> list = load(c, key);
        for (int i = list.size() - 1; i >= 0; i--) if (list.get(i).url.equals(url)) list.remove(i);
        list.add(0, new Entry(title, url));
        while (list.size() > cap) list.remove(list.size() - 1);
        save(c, key, list);
    }

    static void remove(Context c, String key, String url) {
        List<Entry> list = load(c, key);
        for (int i = list.size() - 1; i >= 0; i--) if (list.get(i).url.equals(url)) list.remove(i);
        save(c, key, list);
    }

    static void clear(Context c, String key) {
        sp(c).edit().remove(key).apply();
    }
}
